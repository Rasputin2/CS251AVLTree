/*test.cpp*/

#include <iostream>
#include <vector>

#include "avl.h"

#define CATCH_CONFIG_MAIN
#include "catch.hpp"

using namespace std;

TEST_CASE("(A) empty tree") 
{
  avltree<int, int>  avl;

  REQUIRE(avl.size() == 0);
  REQUIRE(avl.height() == -1);
}

TEST_CASE("(B) just one node") 
{
  avltree<int, int>  avl;
	
	avl.insert(123, 88);

  REQUIRE(avl.size() == 1);
  REQUIRE(avl.height() == 0);
	
	vector<int>  keys, values, heights;

  keys = avl.inorder_keys();
  values = avl.inorder_values();
  heights = avl.inorder_heights();

	REQUIRE(keys[0] == 123);
	REQUIRE(values[0] == 88);
    REQUIRE(heights[0] == 0);
}

TEST_CASE("(C) AVL tree with 4 nodes") 
{
  avltree<int, int>  avl;

  //
  // build a simple BST tree with 4 nodes:
  //
  avl.insert(100, -100);
  avl.insert(50, -50);
  avl.insert(150, -150);
  avl.insert(125, -125);

  // 
  // Tests:
  //
  vector<int>  keys, values, heights;

  keys = avl.inorder_keys();
  values = avl.inorder_values();
  heights = avl.inorder_heights();

  REQUIRE(avl.size() == 4);
  REQUIRE(avl.height() == 2);

  REQUIRE(keys[0] == 50);
  REQUIRE(values[0] == -50);
  REQUIRE(heights[0] == 0);

  REQUIRE(keys[1] == 100);
  REQUIRE(values[1] == -100);
  REQUIRE(heights[1] == 2);

  REQUIRE(keys[2] == 125);
  REQUIRE(values[2] == -125);
  REQUIRE(heights[2] == 0);

  REQUIRE(keys[3] == 150);
  REQUIRE(values[3] == -150);
  REQUIRE(heights[3] == 1);
}

TEST_CASE("(1) Break Occurs at Root -- Case 1: One Rotation Required") 
{
  avltree<int, int>  avl;

  //
  // build a simple BST tree with 3 nodes:
  //
  avl.insert(100, -100);
  avl.insert(90, -90);
  avl.insert(80, -80);

  // 
  // Tests:
  //
  vector<int>  keys, values, heights;

  keys = avl.inorder_keys();
  values = avl.inorder_values();
  heights = avl.inorder_heights();

  REQUIRE(avl.size() == 3);
  REQUIRE(avl.height() == 1);

  REQUIRE(keys[0] == 80);
  REQUIRE(values[0] == -80);
  REQUIRE(heights[0] == 0);

  REQUIRE(keys[1] == 90);
  REQUIRE(values[1] == -90);
  REQUIRE(heights[1] == 1);

  REQUIRE(keys[2] == 100);
  REQUIRE(values[2] == -100);
  REQUIRE(heights[2] == 0);
}

TEST_CASE("(2) Break Occurs at Root -- Case 2:  Left Child/Right Subtree -- Two Rotations Required") 
{
  avltree<int, int>  avl;

  //
  // build a simple BST tree with 3 nodes:
  //
  avl.insert(100, -100);
  avl.insert(50, -50);
  avl.insert(75, -75);
 
  // 
  // Tests:
  //
  vector<int>  keys, values, heights;

  keys = avl.inorder_keys();
  values = avl.inorder_values();
  heights = avl.inorder_heights();

  REQUIRE(avl.size() == 3);
  REQUIRE(avl.height() == 1);

  REQUIRE(keys[0] == 50);
  REQUIRE(values[0] == -50);
  REQUIRE(heights[0] == 0);

  REQUIRE(keys[1] == 75);
  REQUIRE(values[1] == -75);
  REQUIRE(heights[1] == 1);

  REQUIRE(keys[2] == 100);
  REQUIRE(values[2] == -100);
  REQUIRE(heights[2] == 0);
}

TEST_CASE("(3) Break Occurs at Root -- Case 3: Right Child / Left SubTree -- Two Rotations Required") 
{
  avltree<int, int>  avl;

  //
  // build a simple BST tree with 3 nodes:
  //
  avl.insert(100, -100);
  avl.insert(120, -120);
  avl.insert(110, -110);
 
  // 
  // Tests:
  //
  vector<int>  keys, values, heights;

  keys = avl.inorder_keys();
  values = avl.inorder_values();
  heights = avl.inorder_heights();

  REQUIRE(avl.size() == 3);
  REQUIRE(avl.height() == 1);

  REQUIRE(keys[0] == 100);
  REQUIRE(values[0] == -100);
  REQUIRE(heights[0] == 0);

  REQUIRE(keys[1] == 110);
  REQUIRE(values[1] == -110);
  REQUIRE(heights[1] == 1);

  REQUIRE(keys[2] == 120);
  REQUIRE(values[2] == -120);
  REQUIRE(heights[2] == 0);
}

TEST_CASE("(4) Break Occurs at Root -- Case 4: One Rotation Required") 
{
  avltree<int, int>  avl;

  //
  // build a simple BST tree with 4 nodes:
  //
  avl.insert(100, -100);
  avl.insert(110, -110);
  avl.insert(120, -120);
 
  // 
  // Tests:
  //
  vector<int>  keys, values, heights;

  keys = avl.inorder_keys();
  values = avl.inorder_values();
  heights = avl.inorder_heights();

  REQUIRE(avl.size() == 3);
  REQUIRE(avl.height() == 1);

  REQUIRE(keys[0] == 100);
  REQUIRE(values[0] == -100);
  REQUIRE(heights[0] == 0);

  REQUIRE(keys[1] == 110);
  REQUIRE(values[1] == -110);
  REQUIRE(heights[1] == 1);

  REQUIRE(keys[2] == 120);
  REQUIRE(values[2] == -120);
  REQUIRE(heights[2] == 0);
}

TEST_CASE("(5) Break Occurs at Left Subtree -- Case 1: One Rotation Required") 
{
  avltree<int, int>  avl;

  //
  // build a simple BST tree with 5 nodes:
  //
  avl.insert(100, -100);
  avl.insert(50, -50);
  avl.insert(110,-110);
  avl.insert(25, -25);
  avl.insert(10, -10);

  // 
  // Tests:
  //
  vector<int>  keys, values, heights;

  keys = avl.inorder_keys();
  values = avl.inorder_values();
  heights = avl.inorder_heights();

  REQUIRE(avl.size() == 5);
  REQUIRE(avl.height() == 2);

  REQUIRE(keys[0] == 10);
  REQUIRE(values[0] == -10);
  REQUIRE(heights[0] == 0);

  REQUIRE(keys[1] == 25);
  REQUIRE(values[1] == -25);
  REQUIRE(heights[1] == 1);

  REQUIRE(keys[2] == 50);
  REQUIRE(values[2] == -50);
  REQUIRE(heights[2] == 0);

  REQUIRE(keys[3] == 100);
  REQUIRE(values[3] == -100);
  REQUIRE(heights[3] == 2);
}

TEST_CASE("(6) Break Occurs at Left Subtree -- Case 2(Left Child/Right SubTree - Under Break Node): Two Rotations Required") 
{
  avltree<int, int>  avl;

  //
  // build a simple BST tree with 4 nodes:
  //
  avl.insert(100, -100);
  avl.insert(110, -110);
  avl.insert(50, -50);  // Break Occurs Here
  avl.insert(40, -40);  // Left Child of Broken Node
  avl.insert(45, -45);  // Right Subtree

  // 
  // Tests:
  //
  vector<int>  keys, values, heights;

  keys = avl.inorder_keys();
  values = avl.inorder_values();
  heights = avl.inorder_heights();

  REQUIRE(avl.size() == 5);
  REQUIRE(avl.height() == 2);

  REQUIRE(keys[0] == 40);
  REQUIRE(values[0] == -40);
  REQUIRE(heights[0] == 0);

  REQUIRE(keys[1] == 45);
  REQUIRE(values[1] == -45);
  REQUIRE(heights[1] == 1);

  REQUIRE(keys[2] == 50);
  REQUIRE(values[2] == -50);
  REQUIRE(heights[2] == 0);

  REQUIRE(keys[3] == 100);
  REQUIRE(values[3] == -100);
  REQUIRE(heights[3] == 2);
}

TEST_CASE("(7) Break Occurs at Left Subtree -- Case 3 (Right Child / Left Subtree - Under Break Node): Two Rotations Required") 
{
  avltree<int, int>  avl;

  //
  // build a simple BST tree with 4 nodes:
  //
  avl.insert(100, -100);
  avl.insert(110, -110);
  avl.insert(50, -50);
  avl.insert(75, -75);
  avl.insert(60, -60);

  // 
  // Tests:
  //
  vector<int>  keys, values, heights;

  keys = avl.inorder_keys();
  values = avl.inorder_values();
  heights = avl.inorder_heights();

  REQUIRE(avl.size() == 5);
  REQUIRE(avl.height() == 2);

  REQUIRE(keys[0] == 50);
  REQUIRE(values[0] == -50);
  REQUIRE(heights[0] == 0);

  REQUIRE(keys[1] == 60);
  REQUIRE(values[1] == -60);
  REQUIRE(heights[1] == 1);

  REQUIRE(keys[2] == 75);
  REQUIRE(values[2] == -75);
  REQUIRE(heights[2] == 0);

  REQUIRE(keys[3] == 100);
  REQUIRE(values[3] == -100);
  REQUIRE(heights[3] == 2);
	
  REQUIRE(keys[4] == 110);
  REQUIRE(values[4] == -110);
  REQUIRE(heights[4] == 0);
}

TEST_CASE("(8) Break Occurs at Left Subtree -- Case 4(Right Subtree of Right Child): One Rotation Required") 
{
  avltree<int, int>  avl;

  //
  // build a simple BST tree with 4 nodes:
  //
  avl.insert(100, -100);
  avl.insert(90, -90);
  avl.insert(110, -110);  // Break Occurs Here
  avl.insert(120, -120);  // Left Child of Broken Node
  avl.insert(130, -130);  // Right Subtree

  // 
  // Tests:
  //
  vector<int>  keys, values, heights;

  keys = avl.inorder_keys();
  values = avl.inorder_values();
  heights = avl.inorder_heights();

  REQUIRE(avl.size() == 5);
  REQUIRE(avl.height() == 2);
 
	
  REQUIRE(keys[0] == 90);
  REQUIRE(values[0] == -90);
  REQUIRE(heights[0] == 0);
	
  REQUIRE(keys[1] == 100);
  REQUIRE(values[1] == -100);
  REQUIRE(heights[1] == 2);

  REQUIRE(keys[2] == 110);
  REQUIRE(values[2] == -110);
  REQUIRE(heights[2] == 0);

  REQUIRE(keys[3] == 120);
  REQUIRE(values[3] == -120);
  REQUIRE(heights[3] == 1);

  REQUIRE(keys[4] == 130);
  REQUIRE(values[4] == -130);
  REQUIRE(heights[4] == 0);
}

TEST_CASE("(9) Break Occurs at Right Subtree -- Case 1: One Rotation Required") 
{
  avltree<int, int>  avl;

  //
  // build a simple BST tree with 4 nodes:
  //
  avl.insert(100, -100);
  avl.insert(90, -90);
  avl.insert(110, -110);  // Break Occurs Here
  avl.insert(109, -109);  // Left Child of Broken Node
  avl.insert(108, -108);  // Right Subtree

  // 
  // Tests:
  //
  vector<int>  keys, values, heights;

  keys = avl.inorder_keys();
  values = avl.inorder_values();
  heights = avl.inorder_heights();

  REQUIRE(avl.size() == 5);
  REQUIRE(avl.height() == 2);

  REQUIRE(keys[0] == 90);
  REQUIRE(values[0] == -90);
  REQUIRE(heights[0] == 0);

  REQUIRE(keys[1] == 100);
  REQUIRE(values[1] == -100);
  REQUIRE(heights[1] == 2);

  REQUIRE(keys[2] == 108);
  REQUIRE(values[2] == -108);
  REQUIRE(heights[2] == 0);

  REQUIRE(keys[3] == 109);
  REQUIRE(values[3] == -109);
  REQUIRE(heights[3] == 1);
	
  REQUIRE(keys[4] == 110);
  REQUIRE(values[4] == -110);
  REQUIRE(heights[4] == 0);	
}

TEST_CASE("(10) Break Occurs at Right Subtree -- Case 2: (Left Child/Right Subtree) -- Two Rotations Required") 
{
  avltree<int, int>  avl;

  //
  // build a simple BST tree with 4 nodes:
  //
  avl.insert(100, -100);
  avl.insert(90, -90);
  avl.insert(130, -130);
  avl.insert(120, -120);
  avl.insert(125, -125);

  // 
  // Tests:
  //
  vector<int>  keys, values, heights;

  keys = avl.inorder_keys();
  values = avl.inorder_values();
  heights = avl.inorder_heights();

  REQUIRE(avl.size() == 5);
  REQUIRE(avl.height() == 2);

  REQUIRE(keys[0] == 90);
  REQUIRE(values[0] == -90);
  REQUIRE(heights[0] == 0);

  REQUIRE(keys[1] == 100);
  REQUIRE(values[1] == -100);
  REQUIRE(heights[1] == 2);

  REQUIRE(keys[2] == 120);
  REQUIRE(values[2] == -120);
  REQUIRE(heights[2] == 0);

  REQUIRE(keys[3] == 125);
  REQUIRE(values[3] == -125);
  REQUIRE(heights[3] == 1);

  REQUIRE(keys[4] == 130);
  REQUIRE(values[4] == -130);
  REQUIRE(heights[4] == 0);
}

TEST_CASE("(11) Break Occurs at Right Subtree -- Case 3: (Right Child/Left Subtree) (Two Rotations Required") 
{
  avltree<int, int>  avl;

  //
  // build a simple BST tree with 4 nodes:
  //
  avl.insert(100, -100);
  avl.insert(75, -75);
  avl.insert(110, -110);
  avl.insert(120, -120);
  avl.insert(115, -115);

  // 
  // Tests:
  //
  vector<int>  keys, values, heights;

  keys = avl.inorder_keys();
  values = avl.inorder_values();
  heights = avl.inorder_heights();

  REQUIRE(avl.size() == 5);
  REQUIRE(avl.height() == 2);

  REQUIRE(keys[0] == 75);
  REQUIRE(values[0] == -75);
  REQUIRE(heights[0] == 0);

  REQUIRE(keys[1] == 100);
  REQUIRE(values[1] == -100);
  REQUIRE(heights[1] == 2);

  REQUIRE(keys[2] == 110);
  REQUIRE(values[2] == -110);
  REQUIRE(heights[2] == 0);

  REQUIRE(keys[3] == 115);
  REQUIRE(values[3] == -115);
  REQUIRE(heights[3] == 1);
	
  REQUIRE(keys[4] == 120);
  REQUIRE(values[4] == -120);
  REQUIRE(heights[4] == 0);
}

TEST_CASE("(12) Break Occurs at Root -- Case 4: One Rotation Required") 
{
  avltree<int, int>  avl;

  //
  // build a simple BST tree with 4 nodes:
  //
  avl.insert(100, -100);
  avl.insert(130, -130);
  avl.insert(140, -140);
  avl.insert(150, -150);

  // 
  // Tests:
  //
  vector<int>  keys, values, heights;

  keys = avl.inorder_keys();
  values = avl.inorder_values();
  heights = avl.inorder_heights();

  REQUIRE(avl.size() == 4);
  REQUIRE(avl.height() == 2);

  REQUIRE(keys[0] == 100);
  REQUIRE(values[0] == -100);
  REQUIRE(heights[0] == 0);

  REQUIRE(keys[1] == 130);
  REQUIRE(values[1] == -130);
  REQUIRE(heights[1] == 2);

  REQUIRE(keys[2] == 140);
  REQUIRE(values[2] == -140);
  REQUIRE(heights[2] == 1);

  REQUIRE(keys[3] == 150);
  REQUIRE(values[3] == -150);
  REQUIRE(heights[3] == 0);
}

TEST_CASE("(D1) K1 = K2") 
{
  avltree<int, int>  avl;

  //
  // build a simple BST tree with 4 nodes:
  //
  avl.insert(100, -100);
  avl.insert( 90, -90);
  avl.insert(140, -140);
  avl.insert( 80, -80);
  avl.insert(130, -150);

  // 
  // Tests:
  //
  
  int distance;
	
  distance = avl.distance(100, 100);
  REQUIRE(distance == 0);
	
  distance = avl.distance(150, 150);
  REQUIRE(distance == -1);
	
  distance = avl.distance(130, 130);
  REQUIRE(distance == 0);
}

TEST_CASE("(D2) K1 or K2 Does Not Exist") 
{
  avltree<int, int>  avl;

  //
  // build a simple BST tree with 4 nodes:
  //
  avl.insert(100, -100);
  avl.insert( 90, -90);
  avl.insert(140, -140);
  avl.insert( 80, -80);
  avl.insert(130, -150);

  // 
  // Tests:
  //
  
  int distance;
	
  distance = avl.distance(101, 100);
  REQUIRE(distance == -1);
	
  distance = avl.distance(100, 102);
  REQUIRE(distance == -1);
}

TEST_CASE("(D3) Common Ancestor is Root inPath is False") 
{
  avltree<int, int>  avl;

  //
  // build a simple BST tree with 4 nodes:
  //
  avl.insert(100, -100);
  avl.insert( 90, -90);
  avl.insert(140, -140);
  avl.insert( 80, -80);
  avl.insert( 95, -95);
  avl.insert(130, -150);
  avl.insert(145, -145);

  // 
  // Tests:
  //
  
  int distance;
	
  distance = avl.distance(80, 130);
  REQUIRE(distance == 4);
	
  distance = avl.distance(80, 145);
  REQUIRE(distance == 4);

  distance = avl.distance(95, 130);
  REQUIRE(distance == 4);
 
  distance = avl.distance(95, 140);
  REQUIRE(distance == 3);

  distance = avl.distance(130, 90);
  REQUIRE(distance == 3);

  distance = avl.distance(145, 90);
  REQUIRE(distance == 3);
}

TEST_CASE("(D4) Common Ancestor is Not Root inPath is False") 
{
  avltree<int, int>  avl;

  //
  // build a simple BST tree with 4 nodes:
  //
  avl.insert(100, -100);
  avl.insert( 90, -90);
  avl.insert(140, -140);
  avl.insert( 80, -80);
  avl.insert( 95, -95);
  avl.insert(130, -150);
  avl.insert(145, -145);
  avl.insert(120, -120);
  avl.insert(142, -142);
  // 
  // Tests:
  //
  
  int distance;
  	
  distance = avl.distance(80, 95);
  REQUIRE(distance == 2);
	
  distance = avl.distance(130, 145);
  REQUIRE(distance == 2);

  distance = avl.distance(120, 145);
  REQUIRE(distance == 3);
 
  distance = avl.distance(120, 142);
  REQUIRE(distance == 4);
}

TEST_CASE("(D5) inPath is True") 
{
  avltree<int, int>  avl;

  //
  // build a simple BST tree with 4 nodes:
  //
  avl.insert(100, -100);
  avl.insert( 90, -90);
  avl.insert(140, -140);
  avl.insert( 80, -80);
  avl.insert( 95, -95);
  avl.insert(130, -150);
  avl.insert(145, -145);
  avl.insert(120, -120);
  avl.insert(142, -142);
  // 
  // Tests:
  //
  
  int distance;
	
  distance = avl.distance(80, 90);
  REQUIRE(distance == 1);
	
  distance = avl.distance(90, 80);
  REQUIRE(distance == 1);

  distance = avl.distance(95, 90);
  REQUIRE(distance == 1);
 
  distance = avl.distance(120, 130);
  REQUIRE(distance == 1);

  distance = avl.distance(130, 120);
  REQUIRE(distance == 1);
	
  distance = avl.distance(145, 140);
  REQUIRE(distance == 1);

  distance = avl.distance(142, 140);
  REQUIRE(distance == 2);

  distance = avl.distance(80, 140);
  REQUIRE(distance == 3);
	
  distance = avl.distance(140, 80);
  REQUIRE(distance == 3);
	
  distance = avl.distance(141,141);
  REQUIRE(distance == -1);
}

TEST_CASE("(D6) Various") 
{
  avltree<int, int>  avl;

  //
  // build a simple BST tree with 4 nodes:
  //
  avl.insert(100, -100);
  avl.insert( 90, -90);
  avl.insert(140, -140);
  avl.insert( 80, -80);
  avl.insert( 95, -95);
  avl.insert(130, -150);
  avl.insert(145, -145);
  avl.insert(120, -120);
  avl.insert(142, -142);
  avl.insert(93, -93);
  avl.insert(133, -133);
  avl.insert(131, -131);
  avl.insert(122, -122);
  // 
  // Tests:
  //
  
  int distance;
 	
  distance = avl.distance(122, 131);
  REQUIRE(distance == 4);

}