/*avl.h*/

//
// AVL tree: this code DOES NOT rebalance.  Right now the heights are updated after
// an insert, but that's it.  Instead, a public "rotate" function is provided that
// lets you call the _RightRotate and _LeftRotate functions in order to test them.
//

#pragma once

#include <iostream>
#include <algorithm>  // std::max
#include <cstdlib>    // std::abs
#include <stack>
#include <vector>
#include <cassert>

using namespace std;

template<typename TKey, typename TValue>

class avltree
{
private:
  struct NODE
  {
    TKey   Key;
    TValue Value;
    int    Height;
    NODE*  Left;
    NODE*  Right;
  };

  NODE* Root;  // pointer to root node of tree (nullptr if empty)
  int   Size;  // # of nodes in the tree (0 if empty)

  // 
  // _inorder does the actual inorder traversal and output 
  // to console.  Each key is output to the console followed
  // by " ", including the last key.
  //
  void _inorder(NODE* cur)
  {
    if (cur == nullptr)
      return;
    else
    {
      _inorder(cur->Left);
      cout << "(" << cur->Key << "," << cur->Value << "," << cur->Height << ")" << " ";
      _inorder(cur->Right);
    }
  }

  void _inorder_keys(NODE* cur, std::vector<TKey>& V)
  {
    if (cur == nullptr)
      return;
    else
    {
      _inorder_keys(cur->Left, V);
      V.push_back(cur->Key);
      _inorder_keys(cur->Right, V);
    }
  }

  void _inorder_values(NODE* cur, std::vector<TValue>& V)
  {
    if (cur == nullptr)
      return;
    else
    {
      _inorder_values(cur->Left, V);
      V.push_back(cur->Value);
      _inorder_values(cur->Right, V);
    }
  }

  void _inorder_heights(NODE* cur, std::vector<int>& V)
  {
    if (cur == nullptr)
      return;
    else
    {
      _inorder_heights(cur->Left, V);
      V.push_back(cur->Height);
      _inorder_heights(cur->Right, V);
    }
  }

  //
  // _copytree:
  //
  // Given a tree, inserts the (key, value) pairs into *this* tree.
  //
  void _copytree(NODE* cur)
  {
    if (cur == nullptr)
      return;
    else
    {
      //
      // to copy and build an exact copy, we need to "visit" cur
      // first and insert that (key, value) pair first.  That way
      // all the nodes to the left will properly go to the left,
      // all the node to the right will properly go to the right.
      //
      insert(cur->Key, cur->Value);

      _copytree(cur->Left);
      _copytree(cur->Right);
    }
  }

  //
  // _RightRotate
  // _LeftRotate
  //
  // Rotates the tree around the node N, where Parent is N's parent.  Note that
  // Parent could be null, which means N is the root of the entire tree.  If 
  // Parent denotes a node, note that N could be to the left of Parent, or to
  // the right.  You'll need to take all this into account when linking in the
  // new root after the rotation.  Don't forget to update the heights as well.
  //
  void _RightRotate(NODE* Parent, NODE* N)
  {
    assert(N != nullptr);  // pre-conditions: N and L must exist
    assert(N->Left != nullptr);
    
    // Declare the Relevant Variables
    NODE* NLeft;
    NODE* NRight;
    NODE* NLeftRight;
    NODE* NLeftLeft;
   
    NLeft      = N->Left;
    NRight     = (N->Right == nullptr) ? nullptr:N->Right;
    NLeftRight = (N->Left->Right == nullptr) ? nullptr:N->Left->Right;
    NLeftLeft  = (N->Left->Left == nullptr) ? nullptr:N->Left->Left;
  
    //Address Parent and the Nodes that Parent is Pointing to
    if (Parent == nullptr) {
       this->Root = NLeft;
    } else if (Parent->Left == N) {
       Parent->Left = NLeft;
    } else {
       Parent->Right = NLeft;   
    }
    
    // Point N to NLeftRight if it Exists
    N->Left = NLeftRight;
	// Point NLeft to N
    NLeft->Right = N;
    
    // Update N's Height
    int HL;
    int HR;
    if (NLeftRight != nullptr ) {
       HL = NLeftRight->Height;
    } else {
       HL = -1;
    }
    if (NRight !=nullptr) {
      HR = NRight->Height;
    } else {
       HR = -1;
    }

    N->Height = 1 + std::max (HL, HR);
    
    // Update NLeft's Height
    if (NLeftLeft != nullptr) {
      HL =  NLeftLeft->Height;
    } else {
      HL = -1; 
    }
    
    HR = N->Height;
    
    NLeft->Height = 1 + std::max (HL, HR);
    
  }
  
  void _LeftRotate(NODE* Parent, NODE* N)
  {
    assert(N != nullptr);  // pre-conditions: N and R must exist
    assert(N->Right != nullptr);
    
    // Declare the Relevant Variables
    NODE* NLeft;      
    NODE* NRight;     
    NODE* NRightRight;
    NODE* NRightLeft; 
   
	NLeft       = (N->Left == nullptr) ? nullptr:N->Left;
    NRight      = N->Right;
    NRightRight = (N->Right->Right == nullptr) ? nullptr:NRight->Right;
    NRightLeft  = (N->Right->Left == nullptr) ? nullptr:NRight->Left;   
   
    //Address Parent and the Nodes that Parent is Pointing to
    if (Parent == nullptr) {
       this->Root = NRight;
    } else if (Parent->Left == N) {
       Parent->Left = NRight;
    } else {
       Parent->Right = NRight;   
    }
    
    // Shift NRightLeft Under N if it Exists
    N->Right = NRightLeft;
	// Point NRight to N
    NRight->Left = N;
    
    // Update N's Height
    int HL;
    int HR;
    if (NLeft != nullptr ) {
       HL = NLeft->Height;
    } else {
       HL = -1;
    }
    if (NRightLeft !=nullptr) {
      HR = NRightLeft->Height;
    } else {
       HR = -1;
    }

    N->Height = 1 + std::max (HL, HR);
    
    // Update NRight's Height
    HL = N->Height;
    
    if (NRightRight != nullptr) {
      HR =  NRightRight->Height;
    } else {
      HR = -1; 
    }
   
    NRight->Height = 1 + std::max (HL, HR);

  }

  // Assumes that the N Node is the Node Where the Break Occurs (Corresponds to N in Insert Function)
  // Assumes that Parent is N's Parent (Corresponds to Prev in Insert Function)
  void _RotateToFix (NODE* parent, NODE* N)
  {
    // pre-conditions: N must exist
	assert(N != nullptr);  

    // Declare Variables:
	int hL  = -1;           // Define Height of Tree Left of NODE
	int hLL = -1;           // Define Height of Left Subtree
	int hLR = -1;           // Define Height of Right Subtree
	int hR  = -1;           // Define Height of Tree Right of NODE
	int hRL = -1;           // Define Height of Left Subtree
	int hRR = -1;           // Define Height of Right Subtree
	
	NODE* NLeft;        // Define Left Node
	NODE* NLeftLeft;    // Define Parent of Left Subtree
	NODE* NLeftRight;   // Define Parent of Right Subtree
	NODE* NRight;       // Define Right Node
	NODE* NRightRight;  // Define Right Subtree
	NODE* NRightLeft;   // Define Left Subtree
    
	// Identify All the Relevant Nodes Below N
	// Update Heights

	// Left Child:
	NLeft = (N->Left == nullptr) ? nullptr:N->Left;
		if (NLeft != nullptr) {
			hL  = (N->Left == nullptr) ? -1:NLeft->Height;
			NLeftLeft = (NLeft->Left == nullptr) ? nullptr:NLeft->Left;
				if (NLeftLeft != nullptr) {
					hLL = (NLeftLeft == nullptr) ? -1:NLeftLeft->Height;
				}
			NLeftRight = (NLeft->Right == nullptr) ? nullptr:NLeft->Right;
				if (NLeftRight != nullptr) {
					hLR = (NLeftRight == nullptr) ? -1:NLeftRight->Height;
				}
		}
	// Right Child:
	NRight = (N->Right == nullptr) ? nullptr:N->Right;
		if (NRight != nullptr) {
			hR  = (NRight == nullptr) ? -1:NRight->Height;
			NRightLeft = (NRight->Left == nullptr) ? nullptr:NRight->Left;
				if (NRightLeft != nullptr) {
					hRL = (NRightLeft == nullptr) ? -1:NRightLeft->Height;
				}
			NRightRight = (NRight->Right==nullptr) ? nullptr:NRight->Right;
				if (NRightRight != nullptr) {
					hRR = (NRightRight == nullptr) ? -1: NRightRight->Height;
				}
		}
	
	if (hL > hR)  // Cases 1 and 2: The Left Node Height is Larger Than the Right Node Height 
	{
		if (hLL > hLR) // Case 1: The Left SubTree Height > Right SubTree Height ... One Right Rotation Required
		{
			_RightRotate (parent, N);
		} else         // Case 2: The Right SubTree Height > Left SubTree Height ... Two Rotations Required ... One Left Rotation Followed by One Right Rotation
		{
			
			_LeftRotate (N, NLeft);
			_RightRotate (parent, N);
		}
	} else        // Cases 3 and 4: The Right Node Height is Larger than the Left Node Height
	{
		if (hRL > hRR) // Case 3: The Left SubTree Height > Right SubTree Height ... Two Rotations Required ... One Right Rotation Followed by One Left Rotation 
		{
			_RightRotate (N, NRight);
			_LeftRotate (parent, N);
		} else 
		{
			_LeftRotate (parent, N);
		}
	}  
	return;
  }
   
  void _deleteTree (NODE* cur) 
  {
	  if (cur == nullptr) {
		  return;
	  } else {
		  _deleteTree(cur->Left);
		  _deleteTree(cur->Right);
		  delete cur;
	  }
  }

public:
  // default constructor:
  // Creates an empty tree.
  avltree()
  {
    Root = nullptr;
    Size = 0;
  }

  // copy constructor:
  // Ensures that if a tree is passed to a function by value
  // the original tree is not changed.
  avltree(avltree& other)
  {
    Root = nullptr;
    Size = 0;

    _copytree(other.Root);
  }
  
  // destructor:
  // Deletes all the nodes in the tree, including Root,
  // and frees up memory.  Tree no longer exists.
  virtual ~avltree()
  {
    // Calls the same helper function as clear function.
	_deleteTree(Root);
	
	return;
  }
  
  // size:
  // Returns the # of nodes in the tree, 0 if empty.
  int size()
  {
    return Size;
  }
  
  // height:
  // Returns the height of the entire tree; the height of an empty tree is
  // defined as -1.
  int height()
  {
    if (Root == nullptr)
      return -1;
    else
      return Root->Height;
  }

  // clear:
  // Deletes all the nodes in the tree, but 
  // resets the Root to nullptr so tree still exists.
  // 
 
  void clear()
  {
    // Re-initialize root pointer and size to "empty":
    // Call Private _deleteTree function
    _deleteTree(Root);
	Root = nullptr;
    Size = 0;
  }
 
  // search:
  // Searches the tree for the given key, returning a pointer to the 
  // value if found and nullptr if not.  We return a pointer so the caller
  // may update the underlying value if needed.
  TValue* search(TKey key)
  {
    NODE* cur = Root;
    while (cur != nullptr)
    {
      if (key == cur->Key)  // already in tree
      {
        return &cur->Value;
      }

      if (key < cur->Key)  // search left:
      {
        cur = cur->Left;
      }
      else
      {
        cur = cur->Right;
      }
    }  

    // if get here, key not found
    return nullptr;
  }

  // insert:
  // Inserts the given (key, value) pair into the tree; if the key has 
  // already been inserted then the function returns without changing 
  // the tree.
  void insert(TKey key, TValue value)
  {
    NODE* prev = nullptr;
    NODE* cur = Root;

    // stack the nodes we visit so we can walk back up
    // the search path later, adjusting heights:
    stack<NODE*> nodes;

    // 1. Search to see if tree already contains key:
    while (cur != nullptr)
    {
      if (key == cur->Key)  // already in tree
        return;

      nodes.push(cur);  // stack so we can return later:

      if (key < cur->Key)  // search left:
      {
        prev = cur;
        cur = cur->Left;
      }
      else
      {
        prev = cur;
        cur = cur->Right;
      }
    }

    // 2. if we get here, key is not in tree, so allocate
    // a new node to insert.
    NODE* newNode;
    newNode = new NODE();
    newNode->Key = key;
    newNode->Value = value;
    newNode->Height = 0;  // leaf node -> sub-tree of height 0:
    newNode->Left = nullptr;
    newNode->Right = nullptr;

    // 3. link in the new node:
    //
    // NOTE: cur is null, and prev denotes node where
    // we fell out of the tree.  if prev is null, then
    // the tree is empty and the Root pointer needs 
    // to be updated.
    //
    if (prev == nullptr)
      Root = newNode;
    else if (key < prev->Key)
      prev->Left = newNode;
    else
      prev->Right = newNode;


    // 4. update size:
    Size++;

    // 5. walk back up tree using stack and update heights.
    while (!nodes.empty())
    {
      cur = nodes.top();
      nodes.pop();
	  if (nodes.empty()) 
	  {
		  prev = nullptr;
	  } else 
	  {
		  prev = nodes.top();
	  }

      int hL = (cur->Left == nullptr) ? -1 : cur->Left->Height;
      int hR = (cur->Right == nullptr) ? -1 : cur->Right->Height;
      int hCur = 1 + std::max(hL, hR);

      if (cur->Height == hCur)  // didn't change, so no need to go further:
        break;
      else  // height changed, update and keep going:
        cur->Height = hCur;
		
	  // Check if AVL Tree is Balanced or Not
	  if (abs(hL-hR) > 1) 
	  {
		// If the difference > 1, then we know tree is unbalanced and we
		// have to call private balancing function.  In this case, the Parent
		// node is prev and the current node is N.
		_RotateToFix (prev, cur);
	  } 

    }//while

    return;
  }

  // distance:
  // Calculates the distance between two (2) keys.
 
  int distance(TKey k1, TKey k2)
  {
  
  int     caTok1Depth;  // Distance From Common Ancestor to k1
  int     caTok2Depth;  // Distance From Common Ancestor to K2
  int     dist;         // Distance Returned to Caller
  int     i;            // Use for iteration
  TValue* value;
  int     k1Depth;
  int     k2Depth;
  int     commonAncestorDepth;
  bool    inPath;        // Used to Determine Whether k1 and k2 Are In Each Other's Paths
  NODE*   cur = new struct NODE;
  NODE*   commonAncestorPtr = new struct NODE;
  std::stack <NODE*> k1stack;   // Stores the Path Traversed for k1
  std::vector <NODE*> k2vector; // Stores the Path TRaversed for k2 
  
  // Initialize Boolean to False
  inPath = 0;
  
  // Initialize commonAncestorPtr to nullptr
  commonAncestorPtr = nullptr;

  // Check to See if k1 == k2
  // Return 0 if it Does 
  if (k1 == k2) {
	  
	  value = search(k1); 
	  
	  if (value == nullptr) {
		  return -1;
	  } else {
		  return 0;
	  }
	  
  }  
  
  // Check to See if k1 Even Exists
  // Return -1 if it Does Not
  value = search(k1);
  if (value == nullptr) {
	  return -1;
  }

  // Check to See if k2 Even Exists
  // Return -1 if it Does Not
  value = search(k2);
  if (value == nullptr) {
	  return -1;
  }
  
  // Search for K1
  // Push Nodes Onto k1Stack As Search Progresses
  // Determine whether inPath Should be True or False
  cur = Root;
  while (cur != nullptr)
  {
    if (k1 == cur->Key)  // Found it!
      {
		k1stack.push(cur);
        break;
      }

    if (k1 < cur->Key)  // search left:
      {
	    k1stack.push(cur); 
		if (cur->Key == k2) {
			inPath = 1;
		}
        cur = cur->Left;
      }
    else
      {
	    k1stack.push(cur);
		if (cur->Key == k2) {
		    inPath = 1;
		}
        cur = cur->Right;
      }
  }  

  // Set k1's Depth Value
  k1Depth = k1stack.size() - 1;

  // Search for K2
  // Push Nodes into K2Vector
  // Determine whether inPath Should be True or False
  cur = Root;
  while (cur != nullptr)
  {
    if (k2 == cur->Key)  // Found it!
      {
		k2vector.push_back(cur);
        break;
      }

    if (k2 < cur->Key)  // search left:
      {
		k2vector.push_back(cur); 
		if (cur->Key == k1) {
			inPath = 1;
		}
        cur = cur->Left;
      }
    else
      {
	    k2vector.push_back(cur);
		if (cur->Key == k2) {
			inPath = 1;
		}
        cur = cur->Right;
      }
  }  
  
  // Set k2's Depth Value
  k2Depth = k2vector.size() - 1;

  // Find Common Ancestor by Popping Nodes
  // from K1stack and K2stack
  
  while (!k1stack.empty()) {
	  
	  for ((i = k2vector.size() - 1); i > -1; --i) {
	  
		  if (k1stack.top()->Key == k2vector[i]->Key) {
	  
			  // Find First Common Ancestor
			  if (commonAncestorPtr == nullptr) {
				  commonAncestorPtr = k1stack.top();
			  } else if ((k1stack.top()->Key < Root->Key) && (k1stack.top()->Height < commonAncestorPtr->Height))
			  {
		
				   commonAncestorPtr = k1stack.top(); // Find Smallest Common Ancestor if Left of Root
			  } else if ((k1stack.top()->Key > Root->Key) && (k1stack.top()->Height < commonAncestorPtr->Height)){
				  
				  commonAncestorPtr = k1stack.top(); // Find Smallest Common Ancestor if Right of Root
			  
			  }

		  }  
	  }  
	  
	  k1stack.pop();	
	  
  } // end while
 
   // Find Common Ancestor Depth
   cur = Root;
   commonAncestorDepth = 0;
   
   while (cur->Key != commonAncestorPtr->Key) { 
	commonAncestorDepth = commonAncestorDepth + 1;
	if (commonAncestorPtr->Key < cur->Key) {
		cur = cur->Left;
	} else {
		cur = cur->Right;
	}
   }
  
  // Find Depth from Common Ancestor to K1
  caTok1Depth = k1Depth - commonAncestorDepth;

  // Find Depth from Common Ancestor to K2
  caTok2Depth = k2Depth - commonAncestorDepth;

  // There Are Two Possible Situations At this Point
  // Situation 1: k1 and k2 are in the same path so Subtract One Depth from Other
  // Situation 2: k1 and k2 are not in the same path so Add One Depth from Other
  
  if (inPath) 
   {
	  dist = abs(caTok1Depth - caTok2Depth);
	  return dist;   // Situation 1
   } else 
   {
	  dist = caTok1Depth + caTok2Depth;
	  return dist;   // Situation 2
   }

  } // end of distance
 
  // inorder:
  // Performs an inorder traversal of the tree, outputting
  // the keys to the console.
  void inorder()
  {
    cout << "Inorder: ";

    _inorder(Root);

    cout << endl;
  }

  std::vector<TKey> inorder_keys()
  {
    std::vector<TKey>  V;

    _inorder_keys(Root, V);

    return V;
  }

  std::vector<TValue> inorder_values()
  {
    std::vector<TValue>  V;

    _inorder_values(Root, V);

    return V;
  }

  std::vector<int> inorder_heights()
  {
    std::vector<int>  V;

    _inorder_heights(Root, V);

    return V;
  }
};